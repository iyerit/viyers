mv README.md README_temp.md
cp CHANGELOG.rst README.md