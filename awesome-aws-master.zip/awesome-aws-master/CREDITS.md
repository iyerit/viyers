# CREDITS

## Content

* [Awesome Python](https://github.com/vinta/awesome-python) as the template used to create this repo.
* [Wikipedia](https://en.wikipedia.org/wiki/Amazon_Web_Services) for portions of the [Appendix of Core Services](#appendix-of-core-services).

## Images

* [Repo Header](https://aws.amazon.com)
* [SDK Header](https://conceptdraw.com/a3125c3/p1/preview/640/pict--aws-architecture-diagram-icons-design-elements-aws-sdks)
* [CLI Header](http://arcanesanctum.net/wp-content/uploads/hasher/terminal.jpg)
* [Eclipse IDE Header](http://help.eclipse.org/juno/topic/org.eclipse.platform.doc.user/whatsNew/images/icon.png)
* [Visual Studio IDE Header](http://www.iconarchive.com/download/i98390/dakirby309/simply-styled/Microsoft-Visual-Studio.ico)
* [GitHub Header](http://itjobsco.com/wp-content/themes/wpjobus/images/github_logo.png)
* [Innovation at Scale Header](https://d1.awsstatic.com/Digital%20Marketing/House/2up/products/quicksight/ha_2up_quicksight.png)
* [Guides Header](http://d1.awsstatic.com/asset-repository/generics/whitepaper/editorial_whitepaper_green.png)
* [Social Header](https://twitter.com/awscloud)
* [Appendix Header](https://console.aws.amazon.com/)