## The Fiery Meter of AWSome
* [user/foo](https://github.com/user/foo) - desc
* [user/bar](https://github.com/user/bar) - desc
* [user/baz :fire:](https://github.com/user/baz) - desc
* [user/qux :fire::fire:](https://github.com/user/qux) - desc
* [user/foobar :fire:](https://github.com/user/foobar) - desc
* [user/bazqux :fire::fire::fire:](https://github.com/user/bazqux) - desc
* [user/exclude](https://github.com/donnemartin) - desc
* [user/exclude](https://github.com/donnemartin/awesome-aws) - desc
* [user/exclude](https://github.com/sindresorhus/awesome) - desc
* [user/exclude](https://github.com/kilimchoi/engineering-blogs) - desc
* [user/exclude](https://github.com/user/foo#)
* [user/broken](https://github.com/user/broken)
