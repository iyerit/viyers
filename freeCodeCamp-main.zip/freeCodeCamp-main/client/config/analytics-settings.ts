export const prodAnalyticsId = 'GTM-57R6KJM';
export const devAnalyticsId = 'GTM-WSS47LM';

// this id includes a stream for the spanish learn platform
export const prodAnalyticsESId = 'GTM-KCS6GSD';
