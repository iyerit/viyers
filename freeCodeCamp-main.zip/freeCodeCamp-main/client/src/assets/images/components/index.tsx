import AlibabaLogo from './alibaba-logo';
import AmazonLogo from './amazon-logo';
import AppleLogo from './apple-logo';
import AsSeenInText from './as-seen-in-text';
import GoogleLogo from './google-logo';
import MicrosoftLogo from './microsoft-logo';
import SpotifyLogo from './spotify-logo';
import TencentLogo from './tencent-logo';

export {
  AmazonLogo,
  AlibabaLogo,
  AppleLogo,
  MicrosoftLogo,
  SpotifyLogo,
  GoogleLogo,
  TencentLogo,
  AsSeenInText
};
