const analytics = {
  event: function (): void {
    // comment necessary for linting.
  }
};

export default analytics;
