#!/bin/sh
serve -c ../serve.json -p $1 public
