module.exports = {
  host: process.env.HOST || 'localhost'
};
